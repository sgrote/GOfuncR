#ifndef READBED_H
#define READBED_H

#include "structures.h"
#include <vector>

std::vector<bed_str> read_bed(std::string bed_file);

#endif
