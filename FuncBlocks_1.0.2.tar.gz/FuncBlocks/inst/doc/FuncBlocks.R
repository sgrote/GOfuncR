## ----style, echo = FALSE, results = 'asis'-------------------------------
BiocStyle::markdown()

## ----global_options, include=FALSE--------------------------------------------------------------------------
knitr::opts_chunk$set(fig.width=10, fig.height=7, warning=FALSE, message=FALSE)
options(width=110)
set.seed(123)

## -----------------------------------------------------------------------------------------------------------
## load FuncBlocks package
require(FuncBlocks)
## create input vector with candidate genes 
test_genes = paste(rep('FABP', 5), c(2,4:7), sep='')
bg_genes = c('NCAPG', 'NGFR', 'NXPH4', 'C21orf59', 'CACNG2', 'AGTR1', 'ANO1', 'BTBD3', 'MTUS1')
genes = c(rep(1,length(test_genes)), rep(0,length(bg_genes)))
names(genes) = c(test_genes, bg_genes)
genes

## ----results='hide'-----------------------------------------------------------------------------------------
## run enrichment analysis
func_out = go_enrich(genes, n_randsets=100)

## -----------------------------------------------------------------------------------------------------------
head(func_out)

## -----------------------------------------------------------------------------------------------------------
sessionInfo()

